public class Estoque {
    private int codProduto;
    private int qtdeEstoque;
    private int qtdPedido;
    private int qtdVenda;

    public Estoque(int codProduto, int qtdeEstoque) {
        this.codProduto = codProduto;
        this.qtdeEstoque = qtdeEstoque;
        this.qtdPedido = 0; // Inicializa pedidos como zero
        this.qtdVenda = 0; // Inicializa vendas como zero
    }

    public int getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(int codProduto) {
        this.codProduto = codProduto;
    }

    public int getQtdeEstoque() {
        return qtdeEstoque;
    }

    public void setQtdeEstoque(int qtdeEstoque) {
        this.qtdeEstoque = qtdeEstoque;
    }

    public int getQtdPedido() {
        return qtdPedido;
    }

    public void setQtdPedido(int qtdPedido) {
        this.qtdPedido = qtdPedido;
    }

    public int getQtdVenda() {
        return qtdVenda;
    }

    public void setQtdVenda(int qtdVenda) {
        this.qtdVenda = qtdVenda;
    }

    // Método para Controle de estoque
    // Método para adicionar produtos ao estoque
    public void adicionarProduto(int quantidade) {
        this.qtdeEstoque += quantidade;
}
    // Método para registrar uma venda
    public void registrarVenda(int quantidade) {
        if (this.qtdeEstoque >= quantidade) {
            this.qtdeEstoque -= quantidade;
            this.qtdVenda += quantidade;
        } else {
            System.out.println("Não há estoque suficiente para realizar esta venda.");
        }
    }

    // Método para registrar um pedido
    public void registrarPedido(int quantidade) {
        this.qtdPedido += quantidade;
    }

    // Método para exibir informações do produto no estoque
    public void exibirInformacoesProduto() {
        System.out.println("Código do Produto: " + codProduto);
        System.out.println("Quantidade em Estoque: " + qtdeEstoque);
        System.out.println("Quantidade em Pedido: " + qtdPedido);
        System.out.println("Quantidade Vendida: " + qtdVenda);
    }
}