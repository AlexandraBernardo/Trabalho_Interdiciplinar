public class Fornecedor {
    private int IDfornecedor;
    private String nomeFornecedor;
    private String CNPJ;
    private String telefone;
    private String email;
    private String Endereco;
    private char genero;
    private String produto;


    public Fornecedor(){

    }
    public int getIDfornecedor() {
        return IDfornecedor;
    }

    public void setIDfornecedor(int IDfornecedor) {
        this.IDfornecedor = IDfornecedor;
    }

    public String getNomeFornecedor() {
        return nomeFornecedor;
    }

    public void setNomeFornecedor(String nomeFornecedor) {
        this.nomeFornecedor = nomeFornecedor;
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String endereco) {
        Endereco = endereco;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }
    // Método toString para exibir os dados do fornecedor
    @Override
    public String toString() {
        return "Fornecedor{" +
                "IDfornecedor=" + IDfornecedor +
                ", NomeFornecedor='" + nomeFornecedor + '\'' +
                ", CNPJ='" + CNPJ + '\'' +
                ", telefone='" + telefone + '\'' +
                ", email='" + email + '\'' +
                ", Endereco='" + Endereco + '\'' +
                ", genero=" + genero +
                ", produto='" + produto + '\'' +
                '}';
    }
}
