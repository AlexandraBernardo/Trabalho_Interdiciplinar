import java.util.ArrayList;

public class Produtos {

    private String nomePerfume;
    private String genero;
    private String designer;
    private String acordes;
    private double volume;
    private String fragrancia;
    private String tipo;
    private float preco;
    private int codperfume;

    public Produtos() {
        // Aqui você pode inicializar os valores padrão, se necessário
        this.nomePerfume = "Sem nome";
        this.genero = "Sem gênero";
        this.designer = "Sem designer";
        this.acordes = "Sem acordes";
        this.volume = 0.0;
        this.fragrancia = "Sem fragrância";
        this.tipo = "Sem tipo";
        this.preco = 0.0f;
        this.codperfume = 0;
    }
    public Produtos(String nomePerfume, String genero, String designer, String acordes, double volume, String fragrancia, String tipo, float preco, int codperfume) {
        this.nomePerfume = nomePerfume;
        this.genero = genero;
        this.designer = designer;
        this.acordes = acordes;
        this.volume = volume;
        this.fragrancia = fragrancia;
        this.tipo = tipo;
        this.preco = preco;
        this.codperfume = codperfume;
    }

    public static ArrayList<Produtos> createProdutos() {
        ArrayList<Produtos> produtos = new ArrayList<Produtos>();

        // Adicionando produtos à lista
        produtos.add(new Produtos("Miss Dior", "Feminino", "Dior", "Amadeirado, Cítrico", 50.0, "Sem fragrância específica", "Eau de Toilette", 500.f, 01));
        produtos.add(new Produtos("Chanel Nº 5", "Feminino", "Chanel", "Floral", 100.0, "Jasmim, Baunilha", "Eau de Parfum", 750.f, 02));
        produtos.add(new Produtos("Acqua di Giò", "Masculino", "Giorgio Armani", "Aquático", 70.0, "Laranja, Limão", "Eau de Toilette", 400.f, 03));
        produtos.add(new Produtos("Dolce & Gabbana Light Blue", "Feminino", "Dolce & Gabbana", "Floral Frutado", 90.0, "Maçã, Cedro", "Eau de Toilette", 600.f, 04));
        produtos.add(new Produtos("Azzaro Pour Homme", "Masculino", "Azzaro", "Amadeirado", 60.0, "Lavanda, Âmbar", "Eau de Toilette", 450.f, 05));

        return produtos;
       }


    public String getNomePerfume() {
        return nomePerfume;
    }

    public void setNomePerfume(String nomePerfume) {
        this.nomePerfume = nomePerfume;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDesigner() {
        return designer;
    }

    public void setDesigner(String designer) {
        this.designer = designer;
    }

    public String getAcordes() {
        return acordes;
    }

    public void setAcordes(String acordes) {
        this.acordes = acordes;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    public String getFragrancia() {
        return fragrancia;
    }

    public void setFragrancia(String fragrancia) {
        this.fragrancia = fragrancia;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public int getCodperfume() {
        return codperfume;
    }

    public void setCodperfume(int codperfume) {
        this.codperfume = codperfume;
    }

    public String toString() {
        return STR."""
Nome do perfume: \{nomePerfume}
Gênero: \{genero}
Designer: \{designer}
Acordes: \{acordes}
Volume: \{volume} mL
Fragrância: \{fragrancia}
Tipo: \{tipo}
Preço: R$\{preco}
Código do perfume: \{codperfume}""";
    }
}
