import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class TelaProduto {
    private JPanel produtoFrame;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton button6;
    private JButton Sair;
    private JLabel Titulo;
    private JLabel Frase;
    private JButton adicionarCarrinhoButton;
    private JButton removerCarrinhoButton;
    private JButton comprarButton;
    private JTextArea carrinhoArea;
    private JLabel totalLabel;
    private JTextField quantidadeField;

    private Map<String, Integer> carrinho;
    private Map<String, Double> precos;

    public TelaProduto() {
        carrinho = new HashMap<>();
        precos = new HashMap<>();
        precos.put("Produto 1", 10.0);
        precos.put("Produto 2", 20.0);
        precos.put("Produto 3", 15.0);
        precos.put("Produto 4", 25.0);
        precos.put("Produto 5", 30.0);
        precos.put("Produto 6", 40.0);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 1");
            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 2");
            }
        });

        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 3");
            }
        });

        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 4");
            }
        });

        button5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 5");
            }
        });

        button6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 6");
            }
        });

        adicionarCarrinhoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String produto = JOptionPane.showInputDialog("Digite o nome do produto:");
                adicionarAoCarrinho(produto);
            }
        });

        removerCarrinhoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String produto = JOptionPane.showInputDialog("Digite o nome do produto para remover:");
                removerDoCarrinho(produto);
            }
        });

        comprarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                finalizarCompra();
            }
        });

        Sair.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    private void adicionarAoCarrinho(String produto) {
        if (produto == null || produto.isEmpty()) {
            JOptionPane.showMessageDialog(produtoFrame, "Produto inválido.");
            return;
        }

        String quantidadeStr = quantidadeField.getText();
        int quantidade;
        try {
            quantidade = Integer.parseInt(quantidadeStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(produtoFrame, "Quantidade inválida.");
            return;
        }

        carrinho.put(produto, carrinho.getOrDefault(produto, 0) + quantidade);
        atualizarCarrinho();
    }

    private void removerDoCarrinho(String produto) {
        if (produto == null || produto.isEmpty()) {
            JOptionPane.showMessageDialog(produtoFrame, "Produto inválido.");
            return;
        }

        carrinho.remove(produto);
        atualizarCarrinho();
    }

    private void atualizarCarrinho() {
        StringBuilder sb = new StringBuilder();
        double total = 0.0;

        for (Map.Entry<String, Integer> entry : carrinho.entrySet()) {
            String produto = entry.getKey();
            int quantidade = entry.getValue();
            double preco = precos.getOrDefault(produto, 0.0);
            double subtotal = quantidade * preco;

            sb.append(produto).append(" - ").append(quantidade).append(" x ").append(preco).append(" = ").append(subtotal).append("\n");
            total += subtotal;
        }

        carrinhoArea.setText(sb.toString());
        totalLabel.setText("Total: " + total);
    }

    private void finalizarCompra() {
        JOptionPane.showMessageDialog(produtoFrame, "Compra finalizada!\nTotal: " + totalLabel.getText());
        carrinho.clear();
        atualizarCarrinho();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Tela de Produtos");
        frame.setContentPane(new TelaProduto().produtoFrame);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
