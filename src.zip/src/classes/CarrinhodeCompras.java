package classes;

import java.util.ArrayList;
import java.util.List;


public class CarrinhodeCompras {
    private int IdProduto;
    private String nomeCliente;
    private String CPF;
    private String Endereco;
    private int qtdProduto;
    private int datadaCompra;
    private String formadePagamento;
    private double valordoFrete;
    private double valorTotal;
    private List<Produtos> produtos;  // Lista para armazenar os produtos no carrinho

    public CarrinhodeCompras() {
        this.produtos = new ArrayList<>();

        // Método para adicionar um produto ao carrinho
        List<Produtos> produtos1 = produtos;
        List<Produtos> produtos2 = produtos;

    }
    public List<Produtos> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produtos> produtos) {
        this.produtos = produtos;
    }
   
    public static void adicionarProduto(Produtos produto) {
    }

    // Getters e Setters
    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public int getIdProduto() {
        return IdProduto;
    }

    public void setIdProduto(int idProduto) {
        IdProduto = idProduto;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String endereco) {
        Endereco = endereco;
    }

    public int getQtdProduto() {
        return qtdProduto;
    }

    public void setQtdProduto(int qtdProduto) {
        this.qtdProduto = qtdProduto;
    }

    public int getDatadaCompra() {
        return datadaCompra;
    }

    public void setDatadaCompra(int datadaCompra) {
        this.datadaCompra = datadaCompra;
    }

    public String getFormadePagamento() {
        return formadePagamento;
    }

    public void setFormadePagamento(String formadePagamento) {
        this.formadePagamento = formadePagamento;
    }

    public double getValordoFrete() {
        return valordoFrete;
    }

    public void setValordoFrete(double valordoFrete) {
        this.valordoFrete = valordoFrete;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public void adicionarItem(Produtos produto) {   // Método para adicionar um produto ao carrinho
        produtos.add(produto); /* Adiciona o produto à lista de produtos do carrinho */
    }

    public void calcularValorTotal() {
        double totalProdutos = 0.0;
        for (Produtos produto : produtos) {
            totalProdutos += produto.getPreco(); // Soma o preço de cada produto ao total
        }
        this.valorTotal = totalProdutos + this.valordoFrete; // Adiciona o valor do frete ao total
    }

    // Método para exibir os itens do carrinho
    public void exibirCarrinho() {
        System.out.println("Carrinho de Compras de " + nomeCliente);
        System.out.println("Produtos:");
        for (Produtos produto : produtos) {
            System.out.println("- " + produto.getNomePerfume() + " | Preço: " + produto.getPreco());
        }
        System.out.println("Valor do Frete: " + valordoFrete);
        System.out.println("Valor Total: " + valorTotal);
    }

    // Método para limpar o carrinho
    public void limparCarrinho() {
        produtos.clear(); // Limpa a lista de produtos do carrinho
        valorTotal = 0.0; // Resetar o valor total do carrinho
    }

}
