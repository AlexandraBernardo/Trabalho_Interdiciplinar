package classes;

public class Cliente<Produtos> {
    private String nome;
    private String CPF;
    private String telefone;
    private String email;
    private char sexo;
    private CarrinhodeCompras carrinhodeCompras;

    public Cliente(String nome, String CPF, String telefone, String email, char sexo) {
        this.nome = nome;
        this.CPF = CPF;
        this.telefone = telefone;
        this.email = email;
        this.sexo = sexo;
        this.carrinhodeCompras = new CarrinhodeCompras();
    }

    // Getters and setters for all private fields
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public CarrinhodeCompras getCarrinhodeCompras() {
        return carrinhodeCompras;
    }

    public void setCarrinhodeCompras(CarrinhodeCompras carrinhodeCompras) {
        this.carrinhodeCompras = carrinhodeCompras;
    }

    public void adicionarProdutoAoCarrinho(Produtos produto) {
        carrinhodeCompras.adicionarItem(produto);
    }

    public void removerProdutoDoCarrinho(Produtos produto) {
        carrinhodeCompras.removerItem(produto);
    }
}
