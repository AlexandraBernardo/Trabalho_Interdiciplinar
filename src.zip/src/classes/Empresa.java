package classes;

public class Empresa {

    private String nome;
    private String CNPJ;
    private String telefone;
    private String email;
    private String endereco;

    public class Cliente extends Empresa{
        private String telefone;

        public Cliente (String nome,String telefone,String email,String endereco){
             super(nome,email);
             this.telefone = telefone;
        }
        public String gettelefone() { return telefone; }
        public void settelefone(String telefone) {
            this.telefone = telefone;
        }
    }
    public class Funcionários extends Empresa{
        private String email;

        public Funcionários (String telefone,String email,String endereco){
            super(nome,telefone);
            this.email = email;
        }
        public String getemail() { return email; }
        public void setemail(String email) {
            this.email = email;
        }
    }

    public Empresa (String nome, String email) {

    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    // Método toString para exibir os dados da empresa
    @Override
    public String toString() {
        return "classes.Empresa{" +
                "nome='" + nome + '\'' +
                ", CNPJ='" + CNPJ + '\'' +
                ", telefone='" + telefone + '\'' +
                ", email='" + email + '\'' +
                ", endereco='" + endereco + '\'' +
                '}';
    }
}
