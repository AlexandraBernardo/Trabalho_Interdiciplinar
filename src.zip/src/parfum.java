import javax.swing.*;

public class parfum {
    private JLabel Titulo;
    private JButton Sair;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton cadastrarButton;
}
