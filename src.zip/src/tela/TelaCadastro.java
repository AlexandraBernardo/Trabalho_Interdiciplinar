package tela;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaCadastro {
    public JPanel cadastroPanel;
    private JTextField txtNome;
    private JTextField txtEmail;
    private JPasswordField txtSenha;
    private JButton cadastrarButton;
    private JButton voltarButton;

    public TelaCadastro() {
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implement registration logic here
                String nome = txtNome.getText();
                String email = txtEmail.getText();
                String senha = new String(txtSenha.getPassword());
                JOptionPane.showMessageDialog(cadastroPanel, "Cadastro realizado com sucesso!");
            }
        });

        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Close registration screen and return to login screen
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(cadastroPanel);
                frame.dispose();
            }
        });
    }
}
