package tela;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaLogin {
    private JFrame frame;
    private JPanel loginPanel;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton loginButton;
    private JButton registerButton;
    private JButton entrarButton;
    private JPasswordField passwordField1;
    private JTextField textField1;
    private JCheckBox checkBox1;

    public TelaLogin() {
        frame = new JFrame("Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        loginPanel = new JPanel();

        JLabel lblUsername = new JLabel("Username:");
        txtUsername = new JTextField(20);

        JLabel lblPassword = new JLabel("Password:");
        txtPassword = new JPasswordField(20);

        loginButton = new JButton("Login");
        registerButton = new JButton("Register");
        entrarButton = new JButton("Entrar");

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implementar ação de login aqui
                String username = txtUsername.getText();
                char[] password = txtPassword.getPassword();
                // Lógica para autenticar usuário
                // Exemplo simples de exibição de dados (substitua pelo seu código real)
                JOptionPane.showMessageDialog(frame, "Username: " + username + "\nPassword: " + new String(password));
            }
        });

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implementar ação de registro aqui
                JOptionPane.showMessageDialog(frame, "Botão de registro clicado.");
            }
        });

        entrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implementar ação do botão "Entrar" aqui
                JOptionPane.showMessageDialog(frame, "Botão 'Entrar' clicado.");
            }
        });

        loginPanel.add(lblUsername);
        loginPanel.add(txtUsername);
        loginPanel.add(lblPassword);
        loginPanel.add(txtPassword);
        loginPanel.add(loginButton);
        loginPanel.add(registerButton);
        loginPanel.add(entrarButton);

        frame.add(loginPanel);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new TelaLogin();
            }
        });
    }
}
