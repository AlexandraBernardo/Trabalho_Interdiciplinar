package tela;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaProdutos {
    public JPanel produtosPanel;
    private JButton produto1Button;
    private JButton produto2Button;
    private JButton produto3Button;
    private JButton produto4Button;
    private JButton produto5Button;
    private JButton produto6Button;
    private JButton adicionarCarrinhoButton;
    private JButton removerCarrinhoButton;
    private JButton finalizarCompraButton;
    private JTextArea carrinhoArea;

    public TelaProdutos() {
        produto1Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 1");
            }
        });

        produto2Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 2");
            }
        });

        produto3Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 3");
            }
        });

        produto4Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 4");
            }
        });

        produto5Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 5");
            }
        });

        produto6Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarAoCarrinho("Produto 6");
            }
        });

        adicionarCarrinhoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String produto = JOptionPane.showInputDialog("Digite o nome do produto:");
                adicionarAoCarrinho(produto);
            }
        });

        removerCarrinhoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String produto = JOptionPane.showInputDialog("Digite o nome do produto para remover:");
                removerDoCarrinho(produto);
            }
        });

        finalizarCompraButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                finalizarCompra();
            }
        });
    }

    private void adicionarAoCarrinho(String produto) {
        carrinhoArea.append(produto + "\n");
    }

    private void removerDoCarrinho(String produto) {
        String carrinhoText = carrinhoArea.getText();
        carrinhoText = carrinhoText.replaceFirst(produto + "\n", "");
        carrinhoArea.setText(carrinhoText);
    }

    private void finalizarCompra() {
        JOptionPane.showMessageDialog(produtosPanel, "Compra finalizada com sucesso!");
        carrinhoArea.setText("");
    }


}
