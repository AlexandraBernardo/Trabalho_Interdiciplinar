package tela;

import javax.swing.*;

public class promocoes {
    private JFrame frame;
    private JPanel panel;
    private JSpinner spinner1;
    private JSpinner spinner2;
    private JSpinner spinner3;
    private JSpinner spinner4;
    private JCheckBox checkBox1;
    private JCheckBox checkBox2;
    private JCheckBox checkBox3;
    private JCheckBox checkBox4;
    private JButton adicionarButton;
    private JButton pagarButton;
    private JButton removerButton;

    public promocoes() {
        frame = new JFrame("Promoções");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();

        spinner1 = new JSpinner();
        spinner2 = new JSpinner();
        spinner3 = new JSpinner();
        spinner4 = new JSpinner();

        checkBox1 = new JCheckBox("Promoção 1");
        checkBox2 = new JCheckBox("Promoção 2");
        checkBox3 = new JCheckBox("Promoção 3");
        checkBox4 = new JCheckBox("Promoção 4");

        adicionarButton = new JButton("Adicionar");
        pagarButton = new JButton("Pagar");
        removerButton = new JButton("Remover");

        panel.add(new JLabel("Selecione as promoções desejadas:"));
        panel.add(checkBox1);
        panel.add(checkBox2);
        panel.add(checkBox3);
        panel.add(checkBox4);

        panel.add(new JLabel("Quantidade de cada promoção:"));
        panel.add(new JLabel("Promoção 1:"));
        panel.add(spinner1);
        panel.add(new JLabel("Promoção 2:"));
        panel.add(spinner2);
        panel.add(new JLabel("Promoção 3:"));
        panel.add(spinner3);
        panel.add(new JLabel("Promoção 4:"));
        panel.add(spinner4);

        panel.add(adicionarButton);
        panel.add(pagarButton);
        panel.add(removerButton);

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new promocoes();
            }
        });
    }
}
